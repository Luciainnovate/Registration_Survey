<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Survey</title>
        <link rel="stylesheet" href="style.css"/>
      
    </head>
   
    <body>
        <div class="back">
            <div class="page-title">SURVEY</div>
        </div>
       
       <div class="header">
		<h2>Click here to fill or to view</h2>
	</div>
	
	<form method="post" action="login.php">

                <p>
                    <a href="Fill out survey.php">Fill out survey</a></br>
                    <a href="View survey results.php">View survey results</a>
                    
		</p>
	</form>
    </body>
</html>
